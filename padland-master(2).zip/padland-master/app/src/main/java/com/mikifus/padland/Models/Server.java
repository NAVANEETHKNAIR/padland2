package com.mikifus.padland.Models;

/**
 * Created by mikifus on 29/05/16.
 */
public class Server {
    public String name;
    public String url;
    public String url_padprefix;
    public boolean jquery;


}
